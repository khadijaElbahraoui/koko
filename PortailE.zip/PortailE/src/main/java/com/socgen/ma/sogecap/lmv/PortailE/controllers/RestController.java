package com.socgen.ma.sogecap.lmv.PortailE.controllers;

import com.socgen.ma.sogecap.lmv.PortailE.entities.Client;
import com.socgen.ma.sogecap.lmv.PortailE.repositories.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.ArrayList;
import java.util.Map;

@org.springframework.web.bind.annotation.RestController
public class RestController {
    @Autowired
    //private ClientRepository clientRepository;
    private final ClientRepository clientRepository;

    RestController(ClientRepository clientRepository) {
        this.clientRepository = clientRepository;
    }


    @GetMapping("/users")
    public ArrayList<Client> listeClient(){
        return (ArrayList<Client>) clientRepository.findAll();
    }
    @PostMapping("/userss")
    Client newClinet(@RequestBody Client newClient) {

        return clientRepository.save(newClient);

    }
    /*public Client clientsave(@RequestBody Map<String, String> body) {
        Client client = new Client();



        String username=body.get("username");
        String password=(body.get("password"));

        return clientRepository.save(new Client(username,password));

    }*/
    //ajouter un produit
    /*@PostMapping(value = "/clients")
    public void ajouterUser(@RequestBody Client client) {
        clientRepository.save(client);
    }*/
}
