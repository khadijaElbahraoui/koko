package com.socgen.ma.sogecap.lmv.PortailE.repositories;

import com.socgen.ma.sogecap.lmv.PortailE.entities.Client;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.ArrayList;

public interface ClientRepository extends JpaRepository<Client,Long> {
   public Client findById(int Id);
}
