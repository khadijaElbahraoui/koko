package com.socgen.ma.sogecap.lmv.PortailE;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortailEApplicationTests {

	@Test
	void contextLoads() {
	}

}
