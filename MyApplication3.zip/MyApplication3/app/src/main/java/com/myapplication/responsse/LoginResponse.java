package com.myapplication.responsse;

import com.google.gson.annotations.SerializedName;
import com.myapplication.beans.UserBean;


public class LoginResponse {
    @SerializedName("user")
    public UserBean user;
    @SerializedName("auth_token")
    public String authToken;
    @SerializedName("status_code")
    int statusCode;



    public LoginResponse(int statusCode, String authToken, UserBean user) {
        this.statusCode = statusCode;
        this.authToken = authToken;
        this.user = user;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }

    public String getAuthToken() {
        return authToken;
    }

    public void setAuthToken(String authToken) {
        this.authToken = authToken;
    }

    public UserBean getUser() {
        return user;
    }

    public void setUser(UserBean user) {
        this.user = user;
    }
}
