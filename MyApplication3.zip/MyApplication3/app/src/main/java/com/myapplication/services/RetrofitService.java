package com.myapplication.services;



import com.myapplication.api.APIUrl;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitService {

    private String user;

    private static ApiService API;

    public static ApiService getService(){

        if(API == null){

            HttpLoggingInterceptor httpLoggingInterceptor = new HttpLoggingInterceptor();
            httpLoggingInterceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
            OkHttpClient okHttpClient = new OkHttpClient.Builder().addInterceptor(httpLoggingInterceptor).build();
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(APIUrl.BASE_URL)

                    .addConverterFactory(GsonConverterFactory.create())
                    .client(okHttpClient)
                    .build();

            API=retrofit.create(ApiService.class);
        }
        return API;



    }

    /*public static synchronized ApiService getInstance(){
        if(API==null){
            API=new ApiService();

        }
        return API;

    }
*/


}
