package com.myapplication.screens;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.socgen.ma.sogecap.lmv.portail.R;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);


    }

    }

