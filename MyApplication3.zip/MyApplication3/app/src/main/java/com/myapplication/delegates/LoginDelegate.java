package com.myapplication.delegates;

import com.myapplication.beans.UserBean;

public interface LoginDelegate {
    void  onLoginSuccess(UserBean user);
    void onLoginFailure(Throwable t);

}

