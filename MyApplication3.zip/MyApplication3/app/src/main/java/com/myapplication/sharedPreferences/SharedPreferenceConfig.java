package com.myapplication.sharedPreferences;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;

import com.myapplication.R;


public class SharedPreferenceConfig {
    private SharedPreferences sh;
    private Context context;
    SharedPreferences.Editor editor;
    String USER_TOKEN = "user_token";
    public static String SHARED_PREF_NAME="LmvSha";
    @SuppressLint("StringFormatInvalid")
    public SharedPreferenceConfig(Context context){
        this.context=context;
        sh=context.getSharedPreferences(context.getResources().getString(R.string.login_preference),Context.MODE_PRIVATE);
        //hawkerauthToken = String.valueOf(response.get("token"));
        // sharedPreferences.edit().putString("token", hawkerauthToken).commit();
        //String token = preferences.getString("token","");
    }
    public void writeLoginStatuts(boolean statuts){
        SharedPreferences.Editor editor=sh.edit();
        editor.putBoolean(context.getResources().getString(R.string.login_statuts_preference),statuts);
        editor.commit();
    }

    public boolean readLoginStatuts(){
        boolean statuts=false;
        statuts=sh.getBoolean(context.getResources().getString(R.string.login_statuts_preference),false);
        return statuts;
    }


        public void saveAuthToken( String token) {
            editor = sh.edit();
            editor.putString(USER_TOKEN, token);
            editor.apply();
        }




    public String fetchAuthToken() {
        return  sh.getString(USER_TOKEN, null);
    }

}
