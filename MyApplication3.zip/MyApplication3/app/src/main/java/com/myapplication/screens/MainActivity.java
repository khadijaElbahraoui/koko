package com.myapplication.screens;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.myapplication.R;


public class MainActivity extends AppCompatActivity   {


    private Button buttonSignIn;
    private Button buttonl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    initForm();

    addBehavior();

    }

    //==============================Forms

    private void initForm(){

        buttonSignIn = (Button) findViewById(R.id.buttonSignIn);
        buttonl=(Button) findViewById(R.id.buttonl);
    }

    //==============================Behaviors
    private void addBehavior() {
        buttonSignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
if(v==buttonSignIn) {
    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
    startActivity(intent);

                    }

            }

        });
        buttonl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(v==buttonl) {
                    finish();
                      System.exit(0);

                }

            }

        });

    }
}

