package com.myapplication.services;



import com.myapplication.beans.UserBean;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.Headers;

public interface ApiService  {

   /*@Headers("content-type: application/json")
    @POST("userss")
    Call<ResponseBody> createUser(@Body UserBean user);*/


    @Headers("content-type: application/json")
    @GET("users")
    Call<ResponseBody> login(@Body UserBean user);

}



















