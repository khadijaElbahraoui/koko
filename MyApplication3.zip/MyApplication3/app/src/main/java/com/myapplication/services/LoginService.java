package com.myapplication.services;

import com.myapplication.beans.UserBean;
import com.myapplication.screens.LoginActivity;


import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginService {




    public static void  login(UserBean user, LoginActivity delegate) {

        //Defining retrofit api service

        ApiService service = RetrofitService.getService();

        //Defining the user object as we need to pass it with the call

        Call<ResponseBody> call;

        call = service.login(user);

        //calling the api

        call.enqueue(new Callback<ResponseBody>() {

            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {


                if(response.isSuccessful()){


                    delegate.onLoginSuccess(user);

                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {

                delegate.onLoginFailure(t);


            }


        });
    }

}
